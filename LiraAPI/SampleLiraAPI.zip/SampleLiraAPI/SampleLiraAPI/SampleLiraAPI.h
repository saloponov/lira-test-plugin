// SampleLiraAPI.h

#pragma once

using namespace System;
using namespace System::Windows;
using namespace System::Windows::Forms;
using namespace System::Collections::Generic;
using namespace LiraAPI;

namespace SampleLiraAPI 
{

	public ref class CSampleLiraAPI : public LiraAPI::ILiraAPI
	{
	public:
		virtual LiraAPI::ReturnCodes ExecuteProgram_Result(IResultLiraAPI ^pResultLiraAPI, int NodesNumber, int ElementsNumber, List<List<FEModel::Results_Key^>^>^ pAllCases, FEModel::Results_Key ^pCurentCase);

	private:
		void WriteReregisterXmlFile();

	};
}
